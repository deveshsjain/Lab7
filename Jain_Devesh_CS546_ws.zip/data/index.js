const recipeData = require("./recipe")

module.exports = {
  recipe: recipeData
};
